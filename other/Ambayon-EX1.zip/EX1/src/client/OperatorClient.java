package client;
import java.net.MalformedURLException;
import java.net.URL;
import javax.xml.ws.Service;
import com.ambayon.operator.fx.OperatorService;

import javax.xml.namespace.QName;


public class OperatorClient {
	public static void main(String[] args) throws MalformedURLException {
		URL url = new URL("http://localhost:10008/compute?wsdl");
		QName qname = new QName("http://impl.ambayon.com/","OperatorServiceImplService");
		Service service = Service.create(url,qname);
		System.out.println("Input 2 & 5");
		OperatorService operator=service.getPort(OperatorService.class);
		System.out.println("Sum:" + operator.getSum(2,5));
		System.out.println("Difference: " + operator.getDifference(2,5));
		System.out.println("Product: " + operator.getProduct(2,5));
		System.out.println("Quotient: " + operator.getQuotient(2,5));
	}
}
